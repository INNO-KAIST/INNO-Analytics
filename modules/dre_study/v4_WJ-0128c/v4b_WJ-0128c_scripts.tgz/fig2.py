import json,numpy as np,matplotlib,glob
matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.family':'Noto Sans CJK JP','font.size':9,'axes.unicode_minus':False})
import sys; sys.path.insert(0,'.')
S=json.load(open('scans.json'));n=S['nir'];P=np.array(n['P']);R=np.array(n['R'])-(1516.0*P-521.9);t=n['turn']
fig,ax=plt.subplots(2,2,figsize=(11,8.4))
# (a) local slope
a=ax[0,0]
for lab,sl,mk in [('실측 올림',slice(0,t+1),'o'),('실측 내림',slice(t+1,None),'s')]:
    p=P[sl];r=R[sl];o=np.argsort(p);p=p[o];r=r[o];m=(r>5e4)&(p<13.2)&(p>=7.0)
    p=p[m];r=r[m]; k=3
    xs=[];ss=[]
    for i in range(0,len(p)-k):
        if p[i+k]/p[i]<1.02: continue
        xs.append(np.sqrt(p[i]*p[i+k])); ss.append(np.log(r[i+k]/r[i])/np.log(p[i+k]/p[i]))
    a.plot(np.array(xs)/6.96,ss,mk,ms=3.5,mfc='none' if mk=='o' else None,color='#b03030',label=lab+' (3점 창)')
a.axhline(0.99,color='#333',lw=1.4); a.text(1.3,0.5,'쌍안정 3준위 방출체 상한 (x ≥ 1.28): 0.99\n실측 10.6–13.2 mW 회귀: 1.19 ± 0.02',fontsize=7.5)
a.plot([1.15,1.28],[1.06,1.06],color='#333',lw=1.4,ls='--'); a.text(1.02,1.18,'x = h 부근 상한 1.06',fontsize=7)
a.axvline(8.77/6.96,color='k',lw=.6,ls=':'); a.text(8.8/6.96,6.5,'올림=내림 (8.77 mW)',fontsize=7)
a.set_yscale('log'); a.set_ylim(0.3,30); a.set_xlabel('P / P↓ (P↓ = 6.96 mW)'); a.set_ylabel('국소 log-기울기 d ln y / d ln P')
a.set_title('(a) 위 가지 기울기: 실측 > 모든 쌍안정 점 방출체의 상한',fontsize=9.5); a.legend(fontsize=7,loc='upper right')
# (b) cluster MC
a=ax[0,1]; C=json.load(open('cluster_mc.json'))
C=[c for c in C if c['hyst']>=1.08 and c['jd']>=30]
a.scatter([max(c['D'],1.5e-3) for c in C],[c['r19'] for c in C],s=8,color='#2a9d8f',alpha=.6,label=f'독립 쌍안정 방출체 클러스터 (가우시안 빔, N 2–40, 무작위 {len(C)}개)')
a.errorbar([0.03],[5.2],xerr=[[0.02],[0.01]],fmt='D',color='#b03030',ms=7,label='실측')
a.set_xlim(1e-3,3);a.axvspan(1e-3,0.05,color='#b03030',alpha=.07);a.text(1.2e-3,8,'실측 허용 (≤ 5 %)\n0 은 1.5e-3 에 표시',fontsize=7)
a.set_xscale('log');a.set_yscale('log');a.set_xlabel('올림/내림 불일치 max|ln(y↑/y↓)|, P ≥ 1.26 P↓');a.set_ylabel('위 가지 상승폭 y(1.87 P↓)/y(P↓+)')
a.set_title('(b) 클러스터: 상승폭을 얻으면 올림·내림이 어긋난다',fontsize=9.5);a.legend(fontsize=7,loc='lower right')
# (c) mixture fit
a=ax[1,0]
from slowz import *
M=json.load(open('mixture_ref.json')); B=json.load(open('mixture.json'))
exec(open('mixture.py').read().split("all=[]")[0])
z=np.linspace(-2.5,2.5,31); wz=np.exp(-z**2/2); wz/=wz.sum(); Gm=np.geomspace(0.3,400,900)
x=np.array(M['x']); pm=params(x[:7]); um,dm=sweep_fast(pm,Gm); fm=features(Gm,um,dm)
Pp=np.geomspace(4.4,13.4,300); g=np.exp(abs(x[8])*z)
Ym=sum(wi*np.exp(np.interp(np.log(Pp*gi*fm['Pup']/x[7]),np.log(Gm),np.log(um))) for gi,wi in zip(g,wz))
A_,B_=M['coef']; yb_u=A_*ybi(Pp,True); yb_d=A_*ybi(Pp,False); ym=B_*Ym
a.plot(P[:t+1],np.clip(R[:t+1],30,None),'o',ms=3,mfc='none',color='#b03030',label='실측 올림 (배경 뺌)')
a.plot(P[t+1:],np.clip(R[t+1:],30,None),'s',ms=2.6,color='#b03030',label='실측 내림')
a.plot(Pp,yb_u+ym,'--',color='#333',lw=1); a.plot(Pp,yb_d+ym,'-',color='#333',lw=1.3,label='혼합 모델 합 (χ²=%.0f, 198점)'%M['chi2'])
a.plot(Pp,ym,':',color='#e76f51',lw=1.3,label='단안정 성분'); a.plot(Pp,yb_d,':',color='#2a9d8f',lw=1.3,label='쌍안정 성분 (내림)')
a.axhline(1500,color='k',lw=.5,ls=':'); a.axvspan(7.0,8.4,color='#e9c46a',alpha=.18); a.text(7.05,2e2,'여기서 실패\n(올림 검출하한 위반,\n접힘 모양)',fontsize=7)
a.set_xscale('log');a.set_yscale('log');a.set_ylim(1e2,3e6);a.set_xlim(4.4,14)
a.set_xticks([5,6,7,8,9,10,12,14]);a.set_xticklabels(['5','6','7','8','9','10','12','14']);a.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
a.set_xlabel('PM2 파워 (mW)');a.set_ylabel('800 nm (cps)')
a.set_title('(c) 쌍안정 1종 + 단안정 문턱분포: 10.6 mW 이상은 맞음 (rms 1.2σ)',fontsize=9.5);a.legend(fontsize=6.8,loc='lower right')
# (d) slow variable
a=ax[1,1]
pts=[]
for f in ['negfb.json','negfb2.json']:
    D=json.load(open(f))
    for k,v in D.items():
        mode=k.split('_')[0]; pts.append((mode,v['f']['hyst'],max(v['ov'],1e-4)))
try:
    for k,v in json.load(open('negfb3.json')).items(): pts.append(('negSE',v['f']['hyst'],max(v['ov'],1e-4)))
except Exception: pass
col={'negSE':'#264653','negW2':'#2a9d8f','posS':'#e76f51'}; lab={'negSE':'음되먹임 (σ_ESA 감소)','negW2':'음되먹임 (3F4 손실 증가)','posS':'양되먹임 (흡수 증가)'}
done=set()
for m,h,o in pts:
    a.scatter(h,100*o,color=col[m],s=28,label=None if m in done else lab[m]); done.add(m)
a.add_patch(plt.Rectangle((1.18,7),0.04,6,color='#b03030',alpha=.35)); a.text(1.24,9,'실측 목표\n(히스테리시스 1.18–1.22,\n과도 상승 ~10 %)',fontsize=7,color='#b03030')
a.set_yscale('log');a.set_ylim(5e-3,5e3);a.set_xlim(0.95,4.5);a.set_xscale('log')
a.set_xticks([1,1.2,1.5,2,3,4]);a.set_xticklabels(['1','1.2','1.5','2','3','4']);a.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
a.set_xlabel('준정적 히스테리시스 P↑/P↓');a.set_ylabel('점등 과도 상승 (%), 1.05·P↑, τ_z = 100·t50')
a.set_title('(d) 느린 변수: 목표 영역에 닿는 γ 가 없다 (한 매개변수 세트)',fontsize=9.5);a.legend(fontsize=7,loc='upper right')
plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/V4b_WJ-0128c_가설시험.png',dpi=170); print('saved')
