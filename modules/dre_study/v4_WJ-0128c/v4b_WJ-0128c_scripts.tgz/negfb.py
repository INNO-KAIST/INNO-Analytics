import json,numpy as np,sys
sys.path.insert(0,'.'); from slowz import *
bi=json.load(open('bi_h12.json')); th=np.array(bi['th']); th[:2]+=np.log10(bi['f']['Pdn']/6.96)
p=params(th); G=np.geomspace(2,40,500)
u0,d0=sweep_fast(p,G); f0=features(G,u0,d0)
Pr=f0['Pup']*1.05; t50=0.0201; tauz=100*t50
res={}
for mode in ['negW2','negSE','posS']:
  for g in [0.03,0.1,0.3]:
    t,y=rise(p,Pr,mode,g,7.0,tauz,6*tauz)
    n3=y[1]; ssv=n3[-1]; ov=n3.max()/ssv-1; i=np.argmax(n3>=0.5*ssv)
    u,d=sweep_fast(p,G,mode,g,7.0); f=features(G,u,d)
    print(mode,'γ',g,'overshoot %.1f%% (t_peak/t50 %.1f) t50/t50_0 %.2f'%(100*ov,t[np.argmax(n3)]/t50,t[i]/t50),'| qs hyst %.3f jumpD %.0f r19 %.2f sHi %.2f'%(f['hyst'],f['jumpD'],f['r19'],f['sHi']),flush=True)
    res[f'{mode}_{g}']=dict(t=t[::5].tolist(),n3=(n3[::5]/ssv).tolist(),f={k:float(v) for k,v in f.items()},ov=float(ov))
json.dump(res,open('negfb.json','w'))
