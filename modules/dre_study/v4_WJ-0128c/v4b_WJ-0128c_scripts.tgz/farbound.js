// 계급 상한: 쌍안정(hyst≥1.02) 점 방출체의 위 가지에서 x=P/P_dn ∈ [1.28,1.9] 국소 log-기울기 최대
const A=require('./fitA.js'); const {D,M,K}=A;
const lo=[-30,-24,0,-4,0,-2,-3], hi=[-17,-13,10,-0.0005,11,8,8];
function feat(th){
  const e=A.envOf(th); const G=D.logGrid(0.3,300,160);
  let yu,yd; try{ yu=D.sweep(M,e,G.map(p=>p*K),+1,1064).n.map(x=>x[2]); yd=D.sweep(M,e,G.map(p=>p*K),-1,1064).n.map(x=>x[2]); }catch(err){ return null; }
  let bu=0,ju=0,bd=0,jd=0; for(let i=0;i<G.length-1;i++){ const a=Math.log(yu[i+1]/yu[i]); if(a>bu){bu=a;ju=i;} const b=Math.log(yd[i+1]/yd[i]); if(b>bd){bd=b;jd=i;} }
  const Pdn=G[jd+1], hyst=G[ju+1]/Pdn; let s=0;
  for(let i=0;i<G.length-1;i++){ const x=G[i]/Pdn; if(x<1.28||x>1.9) continue; s=Math.max(s,Math.log(yd[i+1]/yd[i])/Math.log(G[i+1]/G[i])); }
  return {hyst,jd:Math.exp(bd),s,Pdn};
}
const obj=th=>{ for(let j=0;j<7;j++) if(th[j]<lo[j]||th[j]>hi[j]) return 1e9; const f=feat(th); if(!f) return 1e9; if(f.hyst<1.02||f.jd<10||f.Pdn<1||f.Pdn>100) return 1e6; return -f.s; };
function nm(f,x0,step,iters){ const n=x0.length; let S=[x0.slice()]; for(let i=0;i<n;i++){ const x=x0.slice(); x[i]+=step; S.push(x); } let F=S.map(f);
  for(let it=0;it<iters;it++){ const o=[...S.keys()].sort((a,b)=>F[a]-F[b]); S=o.map(i=>S[i]); F=o.map(i=>F[i]);
    const c=new Array(n).fill(0); for(let i=0;i<n;i++) for(let j=0;j<n;j++) c[j]+=S[i][j]/n;
    const xr=c.map((v,j)=>v+(v-S[n][j])); const fr=f(xr);
    if(fr<F[0]){ const xe=c.map((v,j)=>v+2*(v-S[n][j])); const fe=f(xe); if(fe<fr){S[n]=xe;F[n]=fe;} else {S[n]=xr;F[n]=fr;} }
    else if(fr<F[n-1]){ S[n]=xr;F[n]=fr; }
    else { const xc=c.map((v,j)=>v+0.5*(S[n][j]-v)); const fc=f(xc); if(fc<F[n]){S[n]=xc;F[n]=fc;} else { for(let i=1;i<=n;i++){ S[i]=S[i].map((v,j)=>S[0][j]+0.5*(v-S[0][j])); F[i]=f(S[i]); } } } }
  const i=F.indexOf(Math.min(...F)); return {x:S[i],f:F[i]}; }
const fs=require('fs'); let all=[]; for(const f of fs.readdirSync('.').filter(f=>/^screen_\d+\.json$/.test(f))) all=all.concat(JSON.parse(fs.readFileSync(f)));
const bi=all.filter(o=>o.hyst>1.02&&o.Pdn>1.1&&o.Pup<55).map(o=>({th:o.th,f:feat(o.th)})).filter(o=>o.f&&o.f.hyst>=1.02&&o.f.jd>=10);
bi.sort((a,b)=>b.f.s-a.f.s); console.log('screen bistable',bi.length,'top s',bi.slice(0,5).map(o=>o.f.s.toFixed(3)+'(h'+o.f.hyst.toFixed(3)+')').join(' '));
const out=[]; for(const s of bi.slice(0,5)){ let r=nm(obj,s.th,0.3,250); r=nm(obj,r.x,0.08,150); const f=feat(r.x); out.push({th:r.x,f}); console.log('->',JSON.stringify(f)); }
fs.writeFileSync('farbound.json',JSON.stringify(out));
