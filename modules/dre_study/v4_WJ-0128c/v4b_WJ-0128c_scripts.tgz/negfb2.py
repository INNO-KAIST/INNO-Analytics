import json,numpy as np,sys
sys.path.insert(0,'.'); from slowz import *
bi=json.load(open('bi_h12.json')); th=np.array(bi['th']); th[:2]+=np.log10(bi['f']['Pdn']/6.96)
p=params(th); G=np.geomspace(2,80,500); t50=0.0201; tauz=100*t50
out={}
for mode in ['negSE','negW2']:
  for g in [0.0,1.0,3.0,10.0]:
    u,d=sweep_fast(p,G,mode,g,7.0); f=features(G,u,d)
    Pr=f['Pup']*1.05
    t,y=rise(p,Pr,mode,g,7.0,tauz,6*tauz); n3=y[1]; ov=n3.max()/n3[-1]-1
    print(mode,g,'Pup %.2f Pdn %.2f hyst %.3f r19 %.2f sHi %.3f | rise@1.05Pup overshoot %.1f%% t_peak %.1f t50'%(f['Pup'],f['Pdn'],f['hyst'],f['r19'],f['sHi'],100*ov,t[np.argmax(n3)]/t50),flush=True)
    out[f'{mode}_{g}']=dict(t=(t[::4]/t50).tolist(),y=(n3[::4]/n3[-1]).tolist(),f={k:float(v) for k,v in f.items()},ov=float(ov))
json.dump(out,open('negfb2.json','w'))
