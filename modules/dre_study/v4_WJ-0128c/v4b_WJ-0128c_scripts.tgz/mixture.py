"""이질 독립 방출체 혼합: 쌍안정 3준위 1종(히스테리시스 1.20) + 단안정 3준위 1종(문턱 로그정규 분포). NIR 800 nm 실측과 대조."""
import json,numpy as np,sys,glob
sys.path.insert(0,'.'); from slowz import *
from scipy.optimize import nnls
S=json.load(open('scans.json'));n=S['nir'];P=np.array(n['P']);R=np.array(n['R'])-(1516.0*np.array(n['P'])-521.9);t=n['turn']
idx=np.arange(len(P)); excl={52,53,54,164}
keep=np.array([i not in excl for i in idx]); isup=idx<=t
cens=R<5e4; L=1500.0; rel=0.05
G=np.geomspace(0.3,400,1600)
bi=json.load(open('bi_h12.json')); pb=params(bi['th']); ub,db=sweep_fast(pb,G); fb=features(G,ub,db)
sb=6.96/fb['Pdn']  # 전역 파워 배율: 쌍안정 소등을 6.96 mW 에
def ybi(Pv,up): return np.exp(np.interp(np.log(Pv/sb),np.log(G),np.log(ub if up else db)))
all=[]
for f in glob.glob('screen_*.json'): all+=json.load(open(f))
mono=[o for o in all if o['hyst']<1.02 and 2<o['jumpU']<60 and 1<o['Pup']<40]
print('mono candidates',len(mono))
rng=np.random.default_rng(5); mono=[mono[i] for i in rng.choice(len(mono),min(40,len(mono)),replace=False)]
def chi2(yu_m,yd_m):
    ym=np.where(isup,yu_m,yd_m)
    m=keep&~cens
    # 배율 1 (A,B 에 포함). log 잔차
    r=np.zeros(len(P))
    r[m]=(np.log(R[m])-np.log(ym[m]))/rel
    mc=keep&cens; r[mc]=np.where(ym[mc]>L,np.log(ym[mc]/L)/rel,0)
    return (r[keep]**2).sum(), r
best=None
z=np.linspace(-2.5,2.5,41); wz=np.exp(-z**2/2); wz/=wz.sum()
for k,o in enumerate(mono):
    pm=params(o['th']); um,dm=sweep_fast(pm,G)
    for med in np.geomspace(5,30,26):
        for w in [0.0,0.05,0.1,0.2,0.35]:
            g=np.exp(w*z)
            def ymono(Pv):
                # 단안정 곡선을 문턱이 med mW 가 되도록 이동 (Pup = 가장 가파른 곳)
                return sum(wi*np.exp(np.interp(np.log(Pv*gi*o['Pup']/med),np.log(G),np.log(um))) for gi,wi in zip(g,wz))
            Yb_u=ybi(P,True); Yb_d=ybi(P,False); Ym=ymono(P)
            Yu=np.where(isup,Yb_u,Yb_d)
            m=keep&~cens
            Am=np.vstack([Yu[m],Ym[m]]).T/R[m][:,None]; coef,_=nnls(Am,np.ones(m.sum()))
            if coef.sum()==0: continue
            c2,_=chi2(coef[0]*Yb_u+coef[1]*Ym, coef[0]*Yb_d+coef[1]*Ym)
            if best is None or c2<best[0]: best=(c2,k,med,w,coef.tolist(),o['th'])
    print(k,'best so far %.1f'%best[0],flush=True) if k%10==9 else None
c2,k,med,w,coef,th=best
print('BEST chi2 %.1f  (n=%d)  med %.2f mW w %.2f  A %.3g B %.3g'%(c2,keep.sum(),med,w,coef[0],coef[1]))
json.dump(dict(chi2=c2,med=med,w=w,coef=coef,th_mono=th,th_bi=bi['th'],sb=sb),open('mixture.json','w'))
