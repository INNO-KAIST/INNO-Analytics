import json,numpy as np,sys
sys.path.insert(0,'.'); from slowz import *
bi=json.load(open('bi_h12.json')); th=np.array(bi['th']); th[:2]+=np.log10(bi['f']['Pdn']/6.96)
p=params(th); G=np.geomspace(2,80,500); t50=0.0201; tauz=100*t50; out={}
for g in [0.4,0.5,0.6,0.7,0.8,0.9]:
    u,d=sweep_fast(p,G,'negSE',g,7.0); f=features(G,u,d); Pr=f['Pup']*1.05
    t,y=rise(p,Pr,'negSE',g,7.0,tauz,6*tauz); n3=y[1]; ov=n3.max()/n3[-1]-1
    print('negSE',g,'Pup %.2f Pdn %.2f hyst %.3f jumpD %.0f r19 %.2f sHi %.3f | overshoot %.1f%%'%(f['Pup'],f['Pdn'],f['hyst'],f['jumpD'],f['r19'],f['sHi'],100*ov),flush=True)
    out[str(g)]=dict(f={k:float(v) for k,v in f.items()},ov=float(ov))
json.dump(out,open('negfb3.json','w'))
