import json,numpy as np,sys
sys.path.insert(0,'.'); from slowz import *
from scipy.optimize import minimize
mode=sys.argv[1]; gam0=[float(v) for v in sys.argv[2].split(',')]
G=np.geomspace(0.3,300,600)
def feat(th,lg):
    p=params(th)
    try: u,d=sweep_fast(p,G,mode,10**lg,7.0)
    except Exception: return None
    if not (np.all(np.isfinite(u)) and np.all(np.isfinite(d)) and np.all(u>0) and np.all(d>0)): return None
    f=features(G,u,d)
    if f['Pdn']*1.95>G[-1] or f['Pdn']<G[0]*3: return None
    return f
LO=np.array([-30,-24,0,-4,0,-2,-3,-3]); HI=np.array([-17,-13,10,-0.0005,11,8,8,4])
def obj(x):
    if np.any(x<LO) or np.any(x>HI): return 1e9
    f=feat(x[:7],x[7])
    if f is None: return 1e9
    if f['hyst']<1.1 or f['hyst']>1.35 or f['jumpD']<30: return 1e6-f['hyst']
    pen=0
    if f['hyst']<1.15: pen+=50*np.log(1.15/f['hyst'])
    if f['jumpD']<50: pen+=np.log(50/f['jumpD'])
    return -f['sHi']+pen
mx=json.load(open('maxr19.json')); out=[]
for o in mx[:4]:
    th=np.array(o['th']); th[:2]+=np.log10(o['f']['Pdn']/6.96)
    for g0 in gam0:
        x0=np.append(th,np.log10(g0))
        r=minimize(obj,x0,method='Nelder-Mead',options=dict(maxfev=350,initial_simplex=None,xatol=1e-3,fatol=1e-4))
        f=feat(r.x[:7],r.x[7])
        rec=dict(x=r.x.tolist(),f={k:float(v) for k,v in f.items()} if f else None,start_g=g0)
        out.append(rec); print(mode,'g0',g0,'->',None if f is None else {k:round(float(v),3) for k,v in f.items()},'logγ %.2f'%r.x[7],flush=True)
json.dump(out,open(f'fb_{mode}.json','w'))
