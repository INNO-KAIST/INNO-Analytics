import json,numpy as np,sys
sys.path.insert(0,'.'); exec(open('mixture.py').read().split("all=[]")[0])
from scipy.optimize import minimize
def chi2(yu_m,yd_m):
    ym=np.where(isup,yu_m,yd_m); m=keep&~cens; r=np.zeros(len(P))
    r[m]=(np.log(R[m])-np.log(ym[m]))/rel
    mc=keep&cens; r[mc]=np.where(ym[mc]>L,np.log(ym[mc]/L)/rel,0)
    return (r[keep]**2).sum(), r
B=json.load(open('mixture.json'))
z=np.linspace(-2.5,2.5,31); wz=np.exp(-z**2/2); wz/=wz.sum()
Gm=np.geomspace(0.3,400,900)
Yb_u=ybi(P,True); Yb_d=ybi(P,False); Yu=np.where(isup,Yb_u,Yb_d)
def ev(x,ret=False):
    th=x[:7]; med=x[7]; w=abs(x[8])
    pm=params(th)
    try: um,dm=sweep_fast(pm,Gm)
    except Exception: return 1e9
    if not np.all(um>0): return 1e9
    f=features(Gm,um,dm)
    if f['hyst']>1.03: return 1e9   # 단안정만
    g=np.exp(w*z)
    Ym=sum(wi*np.exp(np.interp(np.log(P*gi*f['Pup']/med),np.log(Gm),np.log(um))) for gi,wi in zip(g,wz))
    m=keep&~cens
    Am=np.vstack([Yu[m],Ym[m]]).T/R[m][:,None]; coef,_=nnls(Am,np.ones(m.sum()))
    c2,r=chi2(coef[0]*Yb_u+coef[1]*Ym, coef[0]*Yb_d+coef[1]*Ym)
    if ret: return c2,r,coef,Ym,f
    return c2
x0=np.append(np.array(B['th_mono']),[B['med'],max(B['w'],0.02)])
print('start',ev(x0),flush=True)
r=minimize(ev,x0,method='Nelder-Mead',options=dict(maxfev=700,xatol=1e-3,fatol=1e-2))
c2,res,coef,Ym,f=ev(r.x,True)
print('refined chi2 %.1f n %d  med %.2f w %.3f'%(c2,keep.sum(),r.x[7],abs(r.x[8])),'mono feat',{k:round(float(v),3) for k,v in f.items()})
json.dump(dict(x=r.x.tolist(),chi2=c2,coef=coef.tolist(),res=res.tolist()),open('mixture_ref.json','w'))
