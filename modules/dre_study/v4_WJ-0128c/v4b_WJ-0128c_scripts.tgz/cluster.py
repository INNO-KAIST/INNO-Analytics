import json,numpy as np,sys
sys.path.insert(0,'.'); from slowz import *
C=json.load(open('curves.json'))['maxr19']; p=params(C['th'])
G=np.geomspace(2,60,1400); up,dn=sweep_qs(p,G,'posS',0.0)
np.savez('single.npz',G=G,up=up,dn=dn)
def cluster(Ps,g,w=None):
    w=np.ones_like(g) if w is None else w
    yu=sum(wi*np.exp(np.interp(np.log(Ps*gi),np.log(G),np.log(up))) for gi,wi in zip(g,w))
    yd=sum(wi*np.exp(np.interp(np.log(Ps*gi),np.log(G),np.log(dn))) for gi,wi in zip(g,w))
    return yu,yd
rng=np.random.default_rng(3)
Ps=np.geomspace(4.4,13.4,400); res={}
for N,aw in [(7,0.3),(7,0.6),(20,1.0),(3,0.6)]:
    r=aw*np.sqrt(rng.random(N)); g=np.exp(-2*r**2)
    yu,yd=cluster(Ps,g); f=features(Ps,yu,yd)
    # 위 가지 국소 기울기 (P>= 1.25 Pdn)
    s=np.diff(np.log(yd))/np.diff(np.log(Ps)); m=Ps[1:]>=1.25*f['Pdn']
    res[f'N{N}_aw{aw}']=dict(g=g.tolist(),yu=yu.tolist(),yd=yd.tolist())
    print(N,aw,'hyst %.3f jumpD %.1f r19 %.2f sHi %.2f  max slope above 1.25Pdn %.2f'%(f['hyst'],f['jumpD'],f['r19'],f['sHi'],s[m].max()))
json.dump(dict(P=Ps.tolist(),**res),open('cluster.json','w'))
