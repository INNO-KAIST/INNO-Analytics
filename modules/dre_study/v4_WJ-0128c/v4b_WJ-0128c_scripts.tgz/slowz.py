"""3준위 Tm + 느린 변수 z (L4 원형). 준정적 S-curve 와 점등 동역학.
z 원천 u: 흡수 광자율 정규화 u = φ(σG n1 + σE n2)/(σE φ_ref)  (열·광화학 공통 대리량)
되먹임 mode: 'negW2'  W2 → W2(1+γz)           (음: 손실 증가)
             'negSE'  σE → σE/(1+γz)          (음: ESA 감소)
             'posS'   σG,σE → ×(1+γz)          (양: 흡수 증가, 열 보조 흡수형)"""
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import fsolve
K=2.6813e5; EPH=6.62607015e-34*2.99792458e8/1064e-9
def params(th):
    sG,sE,W3,b,s31,q22,q23=[10**v for v in th]
    return dict(sG=sG,sE=sE,W2=1000.0,W3=W3,b=b,s31=s31,q22=q22,q23=q23)
def rates(p,P,z,mode,g):
    phi=P*K/EPH; sG,sE,W2=p['sG'],p['sE'],p['W2']
    f=1+g*z
    if mode=='negW2': W2=W2*f
    elif mode=='negSE': sE=sE/f
    elif mode=='posS': sG=sG*f; sE=sE*f
    return phi,sG,sE,W2
def rhs2(n,p,P,z,mode,g):
    n2,n3=n; n1=1-n2-n3
    phi,sG,sE,W2=rates(p,P,z,mode,g)
    W3,b,s31,q22,q23=p['W3'],p['b'],p['s31'],p['q22'],p['q23']
    d2=sG*phi*n1-sE*phi*n2-W2*n2+W3*b*n3+2*s31*n3*n1-q22*n2*n2-2*q23*n2*n2
    d3=sE*phi*n2-W3*n3-s31*n3*n1+q23*n2*n2
    return np.array([d2,d3])
def ufun(n,p,P,Pref):
    n2,n3=n; n1=1-n2-n3; phi=P*K/EPH; phir=Pref*K/EPH
    return phi*(p['sG']*n1+p['sE']*n2)/(p['sE']*phir)
def steady_qs(p,P,n0,mode,g,Pref):
    """준정적(z=u) 정상상태. 앞 해에서 의사시간 적분 후 Newton."""
    def F(n): return rhs2(n,p,P,ufun(n,p,P,Pref),mode,g)
    def ode(t,y): return F(y)
    scale=p['W2']
    sol=solve_ivp(ode,[0,200/scale],n0,method='LSODA',rtol=1e-8,atol=1e-12)
    y=sol.y[:,-1]
    # 수렴 확인: 더 적분
    for _ in range(6):
        r=np.abs(F(y)).max()/(p['W2']+p['W3'])
        if r<1e-10: break
        sol=solve_ivp(ode,[0,2000/scale],y,method='LSODA',rtol=1e-9,atol=1e-13); y=sol.y[:,-1]
    y2,info,ier,msg=fsolve(F,y,full_output=True,xtol=1e-13)
    if ier==1 and np.all(y2>=-1e-12) and y2.sum()<=1+1e-9: y=y2
    return y
def sweep_qs(p,Ps,mode='posS',g=0.0,Pref=7.0):
    Ps=np.asarray(Ps); up=[];dn=[]
    n=np.array([0.0,0.0])
    for P in Ps: n=steady_qs(p,P,n,mode,g,Pref); up.append(n[1])
    n=steady_qs(p,Ps[-1]*1.0,np.array([0.6,0.05]),mode,g,Pref)
    for P in Ps[::-1]: n=steady_qs(p,P,n,mode,g,Pref); dn.append(n[1])
    return np.array(up),np.array(dn[::-1])
def features(Ps,up,dn):
    lu=np.diff(np.log(np.maximum(up,1e-300))); ld=np.diff(np.log(np.maximum(dn,1e-300)))
    ju=np.argmax(lu); jd=np.argmax(ld)
    Pup,Pdn=Ps[ju+1],Ps[jd+1]
    y0=dn[jd+1]; at=lambda r: np.interp(np.log(Pdn*r),np.log(Ps),np.log(dn))
    r19=np.exp(at(1.87))/y0; r12=np.exp(at(1.2))/y0
    sHi=(at(1.9)-at(1.67))/np.log(1.9/1.67)
    return dict(Pup=Pup,Pdn=Pdn,hyst=Pup/Pdn,jumpD=np.exp(ld[jd]),jumpU=np.exp(lu[ju]),r12=r12,r19=r19,sHi=sHi)
def rise(p,P,mode,g,Pref,tauz,tend,n0=None,z0=0.0):
    """완전 동역학 (n2,n3,z). 바닥상태에서 켬."""
    def ode(t,y):
        n=y[:2]; z=y[2]
        d=rhs2(n,p,P,z,mode,g); dz=(ufun(n,p,P,Pref)-z)/tauz
        return [d[0],d[1],dz]
    y0=[0,0,z0] if n0 is None else list(n0)+[z0]
    te=np.concatenate([np.linspace(0,tend*0.02,1500),np.geomspace(tend*0.02,tend,1500)[1:]])
    s=solve_ivp(ode,[0,tend],y0,method='LSODA',rtol=1e-7,atol=1e-12,t_eval=te)
    return s.t,s.y

def _jac(F,y,h=1e-9):
    f0=F(y); J=np.zeros((2,2))
    for j in range(2):
        yp=y.copy(); d=h*max(1e-6,abs(y[j])); yp[j]+=d; J[:,j]=(F(yp)-f0)/d
    return J
def steady_fast(p,P,n0,mode,g,Pref):
    F=lambda n: rhs2(n,p,P,ufun(n,p,P,Pref),mode,g)
    y,info,ier,msg=fsolve(F,n0,full_output=True,xtol=1e-13)
    ok= ier==1 and np.all(y>=-1e-12) and y.sum()<=1+1e-9 and abs(y-n0).max()<0.05
    if ok:
        ev=np.linalg.eigvals(_jac(F,y))
        if np.all(ev.real<0): return y
    return steady_qs(p,P,n0,mode,g,Pref)
def sweep_fast(p,Ps,mode='posS',g=0.0,Pref=7.0):
    Ps=np.asarray(Ps); up=[];dn=[]; n=np.array([0.0,0.0])
    for P in Ps: n=steady_fast(p,P,n,mode,g,Pref); up.append(n[1])
    n=steady_qs(p,Ps[-1],np.array([0.6,0.05]),mode,g,Pref)
    for P in Ps[::-1]: n=steady_fast(p,P,n,mode,g,Pref); dn.append(n[1])
    return np.array(up),np.array(dn[::-1])
