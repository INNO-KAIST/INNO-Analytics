// 점 방출체 3준위: 위 가지(쌍안정, hyst 1.15–1.25, 접힘 대비≥50) 에서 x=P/P_dn ∈ [hyst, 1.9] 의 국소 log-기울기 최대값
const A=require('./fitA.js'); const {D,M,K,names}=A;
const lo=[-30,-24,0,-4,0,-2,-3], hi=[-17,-13,10,-0.0005,11,8,8];
function feat(th){
  const e=A.envOf(th); const G=D.logGrid(0.3,300,160);
  let yu,yd; try{ yu=D.sweep(M,e,G.map(p=>p*K),+1,1064).n.map(x=>x[2]); yd=D.sweep(M,e,G.map(p=>p*K),-1,1064).n.map(x=>x[2]); }catch(err){ return null; }
  let bu=0,ju=0,bd=0,jd=0; for(let i=0;i<G.length-1;i++){ const a=Math.log(yu[i+1]/yu[i]); if(a>bu){bu=a;ju=i;} const b=Math.log(yd[i+1]/yd[i]); if(b>bd){bd=b;jd=i;} }
  const Pdn=G[jd+1], Pup=G[ju+1], hyst=Pup/Pdn;
  let smax=0,xs=0; const sl=[];
  for(let i=jd+1;i<G.length-1;i++){ const x=G[i]/Pdn; if(x<hyst) continue; if(x>1.9) break; const s=Math.log(yd[i+1]/yd[i])/Math.log(G[i+1]/G[i]); if(s>smax){smax=s;xs=x;} }
  // x∈[1.67,1.9] 창 평균 기울기 (실측 창 11.6–13.1 mW 대응)
  const at=r=>yd[G.findIndex(g=>g>=Pdn*r)];
  const sHi=Math.log(at(1.9)/at(1.67))/Math.log(1.9/1.67);
  return {hyst,jd:Math.exp(bd),smax,xs,sHi,Pdn};
}
function obj(th,mode){
  for(let j=0;j<th.length;j++) if(th[j]<lo[j]||th[j]>hi[j]) return 1e9;
  const f=feat(th); if(!f) return 1e9;
  if(f.hyst<1.12||f.hyst>1.3||f.jd<30) return 1e6-f.hyst; let pen=0; if(f.hyst<1.15) pen+=50*Math.log(1.15/f.hyst)+(f.hyst<1.03?5:0); if(f.hyst>1.25) pen+=50*Math.log(f.hyst/1.25);
  if(f.jd<50) pen+=Math.log(50/f.jd);
  return -(mode==='hi'?f.sHi:f.smax)+pen;
}
function nm(f,x0,step,iters){ const n=x0.length; let S=[x0.slice()]; for(let i=0;i<n;i++){ const x=x0.slice(); x[i]+=step; S.push(x); } let F=S.map(f);
  for(let it=0;it<iters;it++){ const o=[...S.keys()].sort((a,b)=>F[a]-F[b]); S=o.map(i=>S[i]); F=o.map(i=>F[i]);
    const c=new Array(n).fill(0); for(let i=0;i<n;i++) for(let j=0;j<n;j++) c[j]+=S[i][j]/n;
    const xr=c.map((v,j)=>v+(v-S[n][j])); const fr=f(xr);
    if(fr<F[0]){ const xe=c.map((v,j)=>v+2*(v-S[n][j])); const fe=f(xe); if(fe<fr){S[n]=xe;F[n]=fe;} else {S[n]=xr;F[n]=fr;} }
    else if(fr<F[n-1]){ S[n]=xr;F[n]=fr; }
    else { const xc=c.map((v,j)=>v+0.5*(S[n][j]-v)); const fc=f(xc); if(fc<F[n]){S[n]=xc;F[n]=fc;} else { for(let i=1;i<=n;i++){ S[i]=S[i].map((v,j)=>S[0][j]+0.5*(v-S[0][j])); F[i]=f(S[i]); } } } }
  const i=F.indexOf(Math.min(...F)); return {x:S[i],f:F[i]}; }
module.exports={feat};
if(require.main===module){
  const mode=process.argv[2]||'max', nst=+process.argv[3]||6;
  const fs=require('fs'); let all=[]; for(const f of fs.readdirSync('.').filter(f=>/^screen_\d+\.json$/.test(f))) all=all.concat(JSON.parse(fs.readFileSync(f)));
  const bi=all.filter(o=>o.hyst>1.08&&o.hyst<1.6&&o.Pdn>1.1&&o.Pup<55);
  // 시작점: 무작위 쌍안정 중 기울기 상위 + 앞선 maxr19 결과
  const sc=bi.map(o=>({th:o.th,f:feat(o.th)})).filter(o=>o.f); sc.sort((a,b)=>(mode==='hi'?b.f.sHi-a.f.sHi:b.f.smax-a.f.smax));
  console.log('screen bistable',sc.length,'top',sc.slice(0,3).map(o=>(mode==='hi'?o.f.sHi:o.f.smax).toFixed(3)).join(' '));
  const mx=JSON.parse(fs.readFileSync('maxr19.json')).map(o=>({th:o.th}));
  const starts=sc.slice(0,nst).concat(mx.slice(0,3));
  const out=[];
  for(const s of starts){ let r=nm(t=>obj(t,mode),s.th,0.4,300); r=nm(t=>obj(t,mode),r.x,0.1,200); const f=feat(r.x); out.push({th:r.x,f});
    console.log(mode,'->',JSON.stringify(Object.fromEntries(Object.entries(f).map(([k,v])=>[k,+v.toFixed(3)])))); }
  fs.writeFileSync('maxslope_'+mode+'.json',JSON.stringify(out));
}
