import json,numpy as np,sys
sys.path.insert(0,'.'); from slowz import *
S=np.load('single2.npz'); G,UP,DN=S['G'],S['up'],S['dn']
def cl(Ps,g):
    lu=np.log(UP); ld=np.log(DN); lG=np.log(G)
    yu=np.zeros_like(Ps); yd=np.zeros_like(Ps)
    for gi in g: yu+=np.exp(np.interp(np.log(Ps*gi),lG,lu)); yd+=np.exp(np.interp(np.log(Ps*gi),lG,ld))
    return yu,yd
rng=np.random.default_rng(11); Ps=np.geomspace(3,40,700); out=[]
for k in range(4000):
    N=int(rng.integers(2,40)); aw=10**rng.uniform(-1.3,0.3); sc=rng.uniform(0,0.3)
    r=aw*np.sqrt(rng.random(N)); g=np.exp(-2*r**2)*np.exp(sc*rng.standard_normal(N))
    yu,yd=cl(Ps,g)
    lu=np.diff(np.log(yu)); ld=np.diff(np.log(yd)); ju=np.argmax(lu); jd=np.argmax(ld)
    Pup,Pdn=Ps[ju+1],Ps[jd+1]
    if Pdn*1.95>Ps[-1]: continue
    m=(Ps>=1.26*Pdn)&(Ps<=1.9*Pdn)
    D=np.max(np.abs(np.log(yu[m]/yd[m])))
    y0=yd[jd+1]; r19=np.interp(np.log(1.87*Pdn),np.log(Ps),yd)/y0
    s=np.diff(np.log(yd))/np.diff(np.log(Ps)); mm=m[1:]&m[:-1]
    out.append(dict(N=N,aw=aw,sc=sc,hyst=Pup/Pdn,jd=float(np.exp(ld[jd])),r19=float(r19),D=float(D),smin=float(s[mm].min()),frac=float(y0/yd[-1])))
json.dump(out,open('cluster_mc.json','w'))
o=[x for x in out if x['hyst']>=1.08 and x['jd']>=30]
print('configs',len(out),'with hyst1.15-1.25 & jumpD>=50:',len(o))
for c in [(lambda x:x['r19']>=4),(lambda x:x['D']<=0.05),(lambda x:x['smin']>=1.0)]:
    print(sum(c(x) for x in o))
both=[x for x in o if x['r19']>=4 and x['D']<=0.05]; print('r19>=4 & D<=0.05:',len(both))
print('min D among r19>=4:',min([x['D'] for x in o if x['r19']>=4],default=None))
print('max r19 among D<=0.05:',max([x['r19'] for x in o if x['D']<=0.05],default=None))
