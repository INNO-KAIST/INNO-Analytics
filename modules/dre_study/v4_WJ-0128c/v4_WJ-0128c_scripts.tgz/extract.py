import h5py,numpy as np,json
U='/root/.claude/uploads/0c3ebbc7-7b2b-513c-a132-6d2362578318/'
out={}
for key,f in [('nir','d1870d20-260702_power_scan_WJ-0128c_14_Oil_NIR.h5'),('blue','0a508110-260702_power_scan_WJ-0128c_19_Oil_Blue.h5')]:
  g=h5py.File(U+f)['measurement/power_scan']
  P=g['apd_counter_powers'][()]*1e3; R=g['apd_counter_apd_count_rates'][()]; raw=g['apd_counter_apd_count_rates_raw'][()]; W=g['wheel_positions'][()]
  t=np.where(np.diff(W)<0)[0][0]
  out[key]=dict(P=P.tolist(),R=R.tolist(),raw=raw.tolist(),turn=int(t))
json.dump(out,open('scans.json','w'))
n=out['nir']; b=out['blue']
Pn=np.array(n['P']);Rn=np.array(n['R']);tn=n['turn']
Pb=np.array(b['P']);Rb=np.array(b['R']);tb=b['turn']
# NIR background: linear fit on lower branch (up sweep P<8.3)
m=(np.arange(len(Pn))<=tn)&(Pn<8.3)
a=np.polyfit(Pn[m],Rn[m],1); print('NIR lower-branch linear fit cps = %.1f*P + %.1f'%(a[0],a[1]))
a0=np.polyfit(np.log(Pn[m]),np.log(Rn[m]),1); print(' loglog slope',a0[0])
bgB=np.mean(np.array(b['R'])[[0,1,2,3,4,5,6,7,8,9,10,131,132,133,134,135]]); print('blue dark',bgB)
def branch(P,R,t,bg,which):
  idx=np.arange(len(P)); s= idx<=t if which=='up' else idx>t
  return P[s],R[s]-bg(P[s])
bn=lambda p:a[0]*p+a[1]
for which in ['up','dn']:
  p,r=branch(Pn,Rn,tn,bn,which); q,s=branch(Pb,Rb,tb,lambda x:bgB,which)
  on=(r>5e4)&(p<13.1); onb=(s>1000)&(q<13.1)
  print(which,'NIR on range %.2f-%.2f'%(p[on].min(),p[on].max()), 'blue on %.2f-%.2f'%(q[onb].min(),q[onb].max()))
  # local slopes binned
  for lo,hi in [(7.0,8.0),(8.0,9.5),(9.5,11),(11,12.8)]:
    mm=on&(p>=lo)&(p<hi); mb=onb&(q>=lo)&(q<hi)
    sn=np.polyfit(np.log(p[mm]),np.log(r[mm]),1)[0] if mm.sum()>2 else np.nan
    sb=np.polyfit(np.log(q[mb]),np.log(s[mb]),1)[0] if mb.sum()>2 else np.nan
    print('  %.1f-%.1f mW slope NIR %.2f (n%d)  blue %.2f (n%d)'%(lo,hi,sn,mm.sum(),sb,mb.sum()))
# blue vs NIR: interpolate NIR down branch at blue powers
p,r=branch(Pn,Rn,tn,bn,'dn'); q,s=branch(Pb,Rb,tb,lambda x:bgB,'dn')
o=np.argsort(p); ri=np.exp(np.interp(np.log(q),np.log(p[o]),np.log(np.clip(r[o],1,None))))
mm=(q>7.2)&(q<13.1)&(s>1000)
print('d ln Blue / d ln NIR (down, 7.2-13.1): %.2f'%np.polyfit(np.log(ri[mm]),np.log(s[mm]),1)[0])
# up branch contrast
for which,P,R,t,bg in [('nir',Pn,Rn,tn,bn),('blue',Pb,Rb,tb,lambda x:bgB)]:
  print(which,'up/down switch powers:')
  for w in ['up','dn']:
    p,r=branch(P,R,t,bg,w); j=np.argmax(np.abs(np.diff(np.log(np.clip(r+bg(p),1,None)))))
    print('  ',w,'%.3f <-> %.3f'%(p[j],p[j+1]))
# same power up vs down on-branch comparison NIR
p1,r1=branch(Pn,Rn,tn,bn,'up'); p2,r2=branch(Pn,Rn,tn,bn,'dn')
for P0 in [8.56,8.64,8.77,9.48,10.43,11.53,12.25]:
  i=np.argmin(abs(p1-P0)); o=np.argsort(p2); rd=np.exp(np.interp(np.log(p1[i]),np.log(p2[o]),np.log(np.clip(r2[o],1,None))))
  print('   P %.3f up %.4g down %.4g ratio up/down %.3f'%(p1[i],r1[i],rd,r1[i]/rd))
