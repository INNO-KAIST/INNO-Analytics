import json,numpy as np,h5py,matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
plt.rcParams.update({'font.family':'Noto Sans CJK JP','font.size':9,'axes.unicode_minus':False})
S=json.load(open('scans.json')); C=json.load(open('curves.json')); F=json.load(open('feat_ug.json'))
bg=lambda p:1516.0*p-521.9
fig,ax=plt.subplots(2,2,figsize=(11,8.2))
# (a) S-curves
a=ax[0,0]
for key,col,lab in [('nir','#b03030','800 nm'),('blue','#2050c0','450+475 nm')]:
  P=np.array(S[key]['P']);R=np.array(S[key]['R']);t=S[key]['turn']
  a.plot(P[:t+1],R[:t+1],'o',ms=3.2,mfc='none',color=col,label=lab+' 올림')
  a.plot(P[t+1:],R[t+1:],'s',ms=2.6,color=col,alpha=.8,label=lab+' 내림')
a.plot(np.linspace(4.4,13.5),bg(np.linspace(4.4,13.5)),':',color='#b03030',lw=1,label='800 nm 선형 배경 (1.52k cps/mW)')
a.set_xscale('log');a.set_yscale('log');a.set_xlabel('PM2 파워 (mW)  [×0.268 → MW/cm², NIR 광학계]');a.set_ylabel('APD 계수율 (cps)')
a.set_xticks([5,6,7,8,9,10,12,14]);a.set_xticklabels(['5','6','7','8','9','10','12','14'])
a.axvspan(6.907,7.008,color='k',alpha=.08);a.axvspan(8.296,8.452,color='k',alpha=.08)
a.set_title('(a) WJ-0128c 파워 스캔: 두 채널 같은 히스테리시스 (P↑/P↓ ≈ 1.20)',fontsize=9.5)
a.legend(fontsize=7,loc='lower right',ncol=1)
# (b) NIR bg-subtracted vs models (normalized at P_dn+)
a=ax[0,1]
P=np.array(S['nir']['P']);R=np.array(S['nir']['R'])-bg(np.array(S['nir']['P']));t=S['nir']['turn']
m=R>5e4; y0=R[163]
a.plot(P[:t+1][m[:t+1]],R[:t+1][m[:t+1]]/y0,'o',ms=3.2,mfc='none',color='#b03030',label='실측 올림 (배경 뺌)')
a.plot(P[t+1:][m[t+1:]],R[t+1:][m[t+1:]]/y0,'s',ms=2.6,color='#b03030',label='실측 내림')
for key,col,lab in [('maxr19','#333','3준위·점 방출체: 위 가지 상승폭 최대화 (히스테리시스 ≥1.15)'),('gauss','#2a9d8f','같은 매개변수·가우시안 빔 면적분'),('fit','#999','3준위 전체 피팅 최적 (chi2≈1.1e4)')]:
  c=C[key]; Pm=np.array(c['P']);u=np.array(c['u']);d=np.array(c['d'])
  i=np.argmax(Pm>=7.01); k=d[i]
  a.plot(Pm,d/k,'-',color=col,lw=1.3,label=lab);a.plot(Pm,u/k,'--',color=col,lw=1)
a.set_xscale('log');a.set_yscale('log');a.set_ylim(3e-3,30);a.set_xlim(4.4,14)
a.set_xticks([5,6,7,8,9,10,12,14]);a.set_xticklabels(['5','6','7','8','9','10','12','14'])
a.set_xlabel('PM2 파워 (mW)');a.set_ylabel('800 nm 신호 / 내림 문턱 직상 값')
a.axhline(1500/y0,color='k',lw=.6,ls=':');a.text(4.5,1500/y0*1.15,'실측 검출 하한(배경 잡음)',fontsize=7)
a.set_title('(b) 점 방출체는 위 가지가 너무 평평, 면적분은 점프가 너무 작다',fontsize=9.5)
a.legend(fontsize=6.6,loc='lower right')
# (c) feature plane
a=ax[1,0]
F=[f for f in F if f['u']['r19']>=1 and f['g']['r19']>=1]
u=np.array([[f['u']['hyst'],f['u']['r19']] for f in F]); g=np.array([[f['g']['hyst'],f['g']['r19']] for f in F])
a.scatter(u[:,0],u[:,1],s=9,color='#333',alpha=.6,label='3준위·점 방출체 (무작위 27,000 세트 중 쌍안정 %d)'%len(u))
a.scatter(g[:,0],g[:,1],s=9,color='#2a9d8f',alpha=.5,marker='^',label='같은 세트·가우시안 빔 면적분')
mx=json.load(open('maxr19.json'))
a.scatter([o['f']['hyst'] for o in mx],[o['f']['r19'] for o in mx],s=30,marker='*',color='#e76f51',label='표적 최대화 (점 방출체) — 상한 ≈2.1')
a.errorbar([1.204],[5.2],xerr=[[0.02],[0.02]],yerr=[[0.3],[3.5]],fmt='D',color='#b03030',ms=7,label='WJ-0128c 실측 (800 nm)')
a.set_xscale('log');a.set_yscale('log');a.set_xlabel('히스테리시스 P↑/P↓');a.set_ylabel('위 가지 상승폭  y(1.87·P↓)/y(P↓+)')
a.set_xlim(1.03,2.1);a.set_ylim(0.8,3e3);a.set_xticks([1.05,1.1,1.2,1.5,2]);a.set_xticklabels(['1.05','1.1','1.2','1.5','2']);a.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
a.set_title('(c) 실측점은 두 극한 사이의 빈 영역에 있다',fontsize=9.5);a.legend(fontsize=6.6,loc='upper right')
# (d) rise
g5=h5py.File('/root/.claude/uploads/0c3ebbc7-7b2b-513c-a132-6d2362578318/c013fe13-260702_rise_time_WJ-0128c_800_nm_at_Threshold.h5')['measurement/ni_daq_pulse_resp']
c=g5['counts'][()].astype(float);c[0]=np.nan;tt=g5['times'][()]
a=ax[1,1]; ss=158.67
b=10; n=len(c)//b; cb=np.nanmean(c[:n*b].reshape(n,b),1); tb=tt[:n*b].reshape(n,b).mean(1)
a.plot((tb-0.001)*1e3,cb/ss,'-',color='#b03030',lw=1)
a.axhline(1,color='k',lw=.5,ls=':');a.set_xscale('symlog',linthresh=2);a.set_xlim(-1,300);a.set_ylim(-0.05,1.3)
a.set_xlabel('시간 (ms, 레이저 켬 = 0; 2 ms 이후 로그)');a.set_ylabel('800 nm / 마지막 50 ms 평균')
a.annotate('t10 0.60 · t50 1.14 · t90 1.88 ms',(1.2,0.5),xytext=(3,0.35),fontsize=7.5,arrowprops=dict(arrowstyle='->',lw=.6))
a.annotate('+10% 과도 상승, ~100 ms 로 이완\n→ n3 가 n2 에 종속된 3준위 모델에선 불가',(8,1.10),xytext=(2.3,1.2),fontsize=7.5)
a.annotate('끔: τ1 ≤ 20 µs (bin 한계) + τ2 0.75 ms (진폭 3.9%)',(250,0.3),xytext=(3,0.12),fontsize=7.5,arrowprops=dict(arrowstyle='->',lw=.6))
a.set_title('(d) 문턱 부근 점등 (휠 247°, PM2 5.70 mW, 다른 지점)',fontsize=9.5)
plt.tight_layout(); plt.savefig('/mnt/user-data/outputs/V4_WJ-0128c_DRE반례시험.png',dpi=170)
print('saved')
