// 특징 공간 탐색: 3준위 모델이 도달 가능한 (P_up/P_down, 위 가지 모양) 영역
const A=require('./fitA.js'); const {D,M,K,names,lo,hi}=A;
const N=+process.argv[2]||4000, seed=+process.argv[3]||1, rnd=D.mulberry(seed);
const G=D.logGrid(1,60,60); // mW, 넓게
const out=[];
for(let k=0;k<N;k++){
  const th=names.map((_,j)=>lo[j]+rnd()*(hi[j]-lo[j]));
  const e=A.envOf(th); let su,sd;
  try{ su=D.sweep(M,e,G.map(p=>p*K),+1,1064); sd=D.sweep(M,e,G.map(p=>p*K),-1,1064);}catch(err){continue;}
  const yu=su.n.map(x=>x[2]), yd=sd.n.map(x=>x[2]);
  // 가장 큰 점프
  let ju=0,jd=0,bu=0,bd=0;
  for(let i=0;i<G.length-1;i++){ const a=Math.log(yu[i+1]/yu[i]); if(a>bu){bu=a;ju=i;} const b=Math.log(yd[i+1]/yd[i]); if(b>bd){bd=b;jd=i;} }
  const Pup=Math.sqrt(G[ju]*G[ju+1]), Pdn=Math.sqrt(G[jd]*G[jd+1]);
  const hyst=Pup/Pdn;
  // 위 가지(내림) 모양: y(1.2 Pdn)/y(Pdn+) , y(1.87 Pdn)/y(Pdn+)
  const f=r=>{ const p=Pdn*r; let i=G.findIndex(g=>g>=p); if(i<1) i=1; return yd[i]; };
  const y0=yd[jd+1];
  out.push({th,Pup,Pdn,hyst,jumpU:Math.exp(bu),jumpD:Math.exp(bd),r12:f(1.2)/y0,r19:f(1.87)/y0,n3top:yd[G.length-1]});
}
require('fs').writeFileSync('screen_'+seed+'.json',JSON.stringify(out));
const bi=out.filter(o=>o.hyst>1.05);
console.log('N',out.length,'bistable(hyst>1.05)',bi.length);
const hs=bi.map(o=>o.hyst).sort((a,b)=>a-b); console.log('hyst quantiles',[0.1,0.5,0.9,1].map(q=>hs[Math.min(hs.length-1,Math.floor(q*hs.length))]?.toFixed(2)));
