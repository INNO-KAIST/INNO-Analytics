// V4-B: 맞춘 매개변수(게이지 W2=1000)로 바닥상태 점등 곡선·감쇠를 예측하고, 게이지 없는 비율로 실측과 대조
const A=require('./fitA.js'); const {D,M,K}=A;
const obs={t10_90:0.60/1.88,t50_90:1.14/1.88,ov:0.10,BA:0.039,slow_t50:0.752/1.14,fast_t50:0.0198/1.14};
function edges(e){ // P_up, P_dn (mW) by fine sweeps
  const G=D.logGrid(0.5,200,400);
  const yu=D.sweep(M,e,G.map(p=>p*K),+1,1064).n.map(x=>x[2]), yd=D.sweep(M,e,G.map(p=>p*K),-1,1064).n.map(x=>x[2]);
  let bu=0,ju=-1,bd=0,jd=-1; for(let i=0;i<G.length-1;i++){ const a=Math.log(yu[i+1]/yu[i]); if(a>bu){bu=a;ju=i;} const b=Math.log(yd[i+1]/yd[i]); if(b>bd){bd=b;jd=i;} }
  return {Pup:G[ju+1],Pdn:G[jd+1],ju:bu,jd:bd};
}
function riseShape(e,P){
  const I=P*K; const c=D.coeffs(M,e), x=D.molFrac(M,e);
  const ss=D.steady(M,c,x,I/D.photonEnergyJ(1064),null).n[2];
  const T=[],Y=[];
  const r=D.integrate(M,e,I,1064,50,null,{maxSteps:60000,onStep:(t,n)=>{T.push(t);Y.push(n[2]/ss);return false;}});
  const at=f=>{ const i=Y.findIndex(v=>v>=f); if(i<1) return null; return T[i-1]+(T[i]-T[i-1])*(f-Y[i-1])/(Y[i]-Y[i-1]); };
  const t10=at(0.1),t50=at(0.5),t90=at(0.9);
  let mx=0,tm=0; Y.forEach((v,i)=>{ if(v>mx){mx=v;tm=T[i];} });
  return {t10,t50,t90,ov:mx-1,tov:tm,ssn:ss};
}
function decayShape(e,P){
  const I=P*K; const c=D.coeffs(M,e), x=D.molFrac(M,e);
  const ss=D.steady(M,c,x,I/D.photonEnergyJ(1064),null).n;
  const T=[],Y=[]; D.integrate(M,e,0,1064,1,ss,{maxSteps:60000,onStep:(t,n)=>{T.push(t);Y.push(n[2]/ss[2]);return false;}});
  // 빠른 τ: 1/e 도달; 느린 성분: 로그 기울기가 안정된 뒤 절편·기울기
  const i1=Y.findIndex(v=>v<=1/Math.E); const tf=i1>0?T[i1]:null;
  // 준정적 꼬리: t = 10·tf .. 
  const pick=tt=>{ const i=T.findIndex(v=>v>=tt); return i<0?null:[T[i],Y[i]]; };
  const a=pick(10*tf), b=pick(30*tf);
  let tsl=null,BA=null; if(a&&b&&a[1]>0&&b[1]>0){ const k=Math.log(a[1]/b[1])/(b[0]-a[0]); tsl=1/k; BA=a[1]*Math.exp(a[0]*k); }
  return {tf,tsl,BA};
}
module.exports={edges,riseShape,decayShape,obs};
if(require.main===module){
  const R=JSON.parse(require('fs').readFileSync(process.argv[2]||'refine.json'));
  const top=R.filter(r=>r.chi2<=R[0].chi2*1.5+50).slice(0,+process.argv[3]||5);
  for(const s of top){
    const e=A.envOf(s.th); const E=edges(e);
    console.log('\nχ²',s.chi2.toFixed(1),'θ',s.th.map(v=>v.toFixed(2)).join(' '),'P_up %.2f P_dn %.2f hyst %.3f'.replace(/%\.\d f/g,''),E.Pup.toFixed(2),E.Pdn.toFixed(2),(E.Pup/E.Pdn).toFixed(3));
    for(const r of [1.005,1.02,1.05,1.1,1.2,1.4,1.7,2.0]){
      const P=E.Pup*r; const rs=riseShape(e,P); const ds=decayShape(e,P);
      if(!rs.t90){ console.log(' r',r,'no ignition'); continue; }
      console.log(` P/P_up ${r.toFixed(3)}  t10/t90 ${(rs.t10/rs.t90).toFixed(3)} t50/t90 ${(rs.t50/rs.t90).toFixed(3)}  overshoot ${(100*rs.ov).toFixed(1)}% @${(rs.tov/rs.t50).toFixed(1)}·t50  | decay τf/t50 ${(ds.tf/rs.t50).toFixed(4)} τslow/t50 ${ds.tsl?(ds.tsl/rs.t50).toFixed(3):'-'} B/A ${ds.BA?ds.BA.toFixed(4):'-'}  | gauge: t50 model(W2=1000) ${(rs.t50*1e3).toFixed(3)} ms`);
    }
  }
  console.log('\n관측:',JSON.stringify(obs));
}
