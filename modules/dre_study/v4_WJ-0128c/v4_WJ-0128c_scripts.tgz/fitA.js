// V4-A: 3준위 Tm PA 모델이 WJ-0128c NIR up/down S-curve(히스테리시스 포함)를 재현할 수 있는가
const D=require('/home/claude/dre/src/dre_core.js');
const S=require('./scans.json');
const K=2.6813e5; // W/cm² per mW (NIR 950 DMSP, A_peak 1.2393 µm²)
const n=S.nir, P=n.P, R=n.R, t=n.turn;
const bg=p=>1516.0*p-521.9;
const up=[],dn=[];
P.forEach((p,i)=>{ const o={P:p,y:R[i]-bg(p),i}; (i<=t?up:dn).push(o); });
const excl=new Set([52,53,54,164]); // 전이 중(한 점 안에서 전환·느린 접근)
const L=1500; // 절단 상한 (cps)
const mk=arr=>arr.filter(o=>!excl.has(o.i)).map(o=>({P:o.P,y:o.y,cens:o.y<5e4}));
const DU=mk(up), DD=mk(dn);
const spec={species:[{id:"Tm",levels:["3H6","3F4","3H4"]}],procs:[
 {type:"abs",sp:"Tm",from:"3H6",to:"3F4",sigma:"sG"},
 {type:"abs",sp:"Tm",from:"3F4",to:"3H4",sigma:"sE"},
 {type:"dec",sp:"Tm",from:"3F4",to:"3H6",k:"W2"},
 {type:"dec",sp:"Tm",from:"3H4",to:"3H6",k:"W3*(1-b)"},
 {type:"dec",sp:"Tm",from:"3H4",to:"3F4",k:"W3*b"},
 {type:"et",d:["Tm","3H4","3F4"],a:["Tm","3H6","3F4"],W:"s31",scale:"none"},
 {type:"et",d:["Tm","3F4","3H6"],a:["Tm","3F4","3F4"],W:"q22",scale:"none"},
 {type:"et",d:["Tm","3F4","3H6"],a:["Tm","3F4","3H4"],W:"q23",scale:"none"}],
 channels:[{id:"800",terms:[["Tm","3H4",1]]},{id:"1800",terms:[["Tm","3F4",1]]}]};
const M=D.compile(spec);
// 게이지: W2 = 1000 s⁻¹ 고정 (정상상태는 전체 배율 k 에 불변 — 절대 시간은 상승 시간으로 고정)
const names=["sG","sE","W3","b","s31","q22","q23"];
const lo=[-27,-22,1,-3,1,-1,-1], hi=[-19,-15,7,-0.001,8,6,6];
const envOf=th=>{const e={W2:1000}; names.forEach((k,j)=>e[k]=Math.pow(10,th[j])); return e;};
function model(th){
  const e=envOf(th);
  const su=D.sweep(M,e,DU.map(o=>o.P*K),+1,1064), sd=D.sweep(M,e,DD.map(o=>o.P*K),-1,1064);
  return {mu:su.n.map(x=>x[2]),md:sd.n.map(x=>x[2]),fails:su.fails+sd.fails};
}
const rel=0.05;
function resid(th){
  let m; try{ m=model(th);}catch(err){ return null; }
  const all=DU.map((o,k)=>[o,m.mu[k]]).concat(DD.map((o,k)=>[o,m.md[k]]));
  let sw=0,sl=0; all.forEach(([o,v])=>{ if(!o.cens){ sw++; sl+=Math.log(o.y)-Math.log(Math.max(v,1e-300)); }});
  const ls=sl/sw; const r=[];
  all.forEach(([o,v])=>{ const pl=Math.log(Math.max(v,1e-300))+ls;
    if(o.cens) r.push(pl>Math.log(L)?(pl-Math.log(L))/rel:0); else r.push((Math.log(o.y)-pl)/rel); });
  return {r,ls,m};
}
const c2=r=>r.reduce((a,v)=>a+v*v,0);
function lmfd(th0,maxit){
  let th=th0.slice(), R0=resid(th); if(!R0) return {chi2:Infinity,th};
  let F=c2(R0.r), mu=1e-2;
  for(let it=0;it<maxit;it++){
    const J=names.map((_,j)=>{ const h=0.003; const tp=th.slice(); tp[j]+=h; const Rp=resid(tp); return Rp?Rp.r.map((v,i)=>(v-R0.r[i])/h):R0.r.map(()=>0); });
    const p=names.length, A=Array.from({length:p},()=>new Array(p).fill(0)), g=new Array(p).fill(0);
    for(let i=0;i<R0.r.length;i++) for(let a=0;a<p;a++){ g[a]+=J[a][i]*R0.r[i]; for(let b=0;b<p;b++) A[a][b]+=J[a][i]*J[b][i]; }
    let ok=false;
    for(let tr=0;tr<12;tr++){
      const Ad=A.map((row,a)=>row.map((v,b)=>a===b?v*(1+mu)+1e-9:v));
      const h=gauss(Ad,g.map(v=>-v)); if(!h){mu*=4;continue;}
      const tn=th.map((v,a)=>Math.min(hi[a],Math.max(lo[a],v+h[a])));
      const Rn=resid(tn); if(Rn&&c2(Rn.r)<F){ const dF=F-c2(Rn.r); th=tn; R0=Rn; F=c2(Rn.r); mu=Math.max(mu/3,1e-7); ok=true; if(dF<1e-6*(1+F)) return {chi2:F,th,R:R0}; break; }
      mu*=4;
    }
    if(!ok) break;
  }
  return {chi2:F,th,R:R0};
}
function gauss(A,b){ const n=b.length, M=A.map((r,i)=>r.concat([b[i]])); for(let c=0;c<n;c++){ let p=c; for(let r=c+1;r<n;r++) if(Math.abs(M[r][c])>Math.abs(M[p][c])) p=r; if(Math.abs(M[p][c])<1e-300) return null; [M[c],M[p]]=[M[p],M[c]]; for(let r=0;r<n;r++){ if(r===c) continue; const f=M[r][c]/M[c][c]; for(let k=c;k<=n;k++) M[r][k]-=f*M[c][k]; } } return M.map((r,i)=>r[n]/r[i]); }
module.exports={M,D,K,DU,DD,names,envOf,resid,model,lmfd,lo,hi,up,dn,bg,c2};
if(require.main===module){
  const N=+process.argv[2]||40, rnd=D.mulberry(+process.argv[3]||7);
  // 탐색 시작점: LHS 전체 범위
  const st=D.lhs(N,names.length,rnd).map(u=>u.map((v,j)=>lo[j]+v*(hi[j]-lo[j])));
  const out=[]; const t0=Date.now();
  st.forEach((s,k)=>{ const r=lmfd(s,60); out.push({chi2:r.chi2,th:r.th}); if(k%5==4) console.error(k+1,'best',Math.min(...out.map(o=>o.chi2)).toFixed(1),((Date.now()-t0)/1000).toFixed(0)+'s'); });
  out.sort((a,b)=>a.chi2-b.chi2);
  require('fs').writeFileSync('fitA_'+(process.argv[3]||7)+'.json',JSON.stringify(out));
  console.log('n data',DU.length+DD.length,'uncens',DU.concat(DD).filter(o=>!o.cens).length);
  out.slice(0,10).forEach(o=>console.log(o.chi2.toFixed(1),o.th.map(v=>v.toFixed(2)).join(' ')));
}
