const A=require('./fitA.js'); const {D,M,K}=A;
const R=JSON.parse(require('fs').readFileSync('maxr19.json'));
for(const s of R){ const e=A.envOf(s.th); const G=D.logGrid(0.3,300,80).map(p=>p*K);
  const ch=0; const ou=D.observe(M,e,G,+1,1064,0,{beam:"gauss"}), od=D.observe(M,e,G,-1,1064,0,{beam:"gauss"});
  let bu=0,ju=0,bd=0,jd=0; for(let i=0;i<G.length-1;i++){ const a=Math.log(ou.y[i+1]/ou.y[i]); if(a>bu){bu=a;ju=i;} const b=Math.log(od.y[i+1]/od.y[i]); if(b>bd){bd=b;jd=i;} }
  const Pdn=G[jd+1]/K, y0=od.y[jd+1]; const at=r=>{ const i=G.findIndex(g=>g>=Pdn*r*K); return od.y[i]; };
  console.log('peak: hyst',s.f.hyst.toFixed(3),'jumpD',s.f.jd.toFixed(0),'r19',s.f.r19.toFixed(2),' | gauss: hyst',(G[ju+1]/G[jd+1]).toFixed(3),'jumpU',Math.exp(bu).toFixed(1),'jumpD',Math.exp(bd).toFixed(1),'r12',(at(1.2)/y0).toFixed(2),'r19',(at(1.87)/y0).toFixed(2));
}
