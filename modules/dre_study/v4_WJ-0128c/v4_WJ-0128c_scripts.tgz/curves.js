const A=require('./fitA.js'); const {D,M,K}=A; const fs=require('fs');
const G=D.logGrid(4,14,400);
const out={};
function pin(th,Pdn){ const t=th.slice(); const d=Math.log10(Pdn/6.96); t[0]+=d; t[1]+=d; return t; }
const mx=JSON.parse(fs.readFileSync('maxr19.json')).sort((a,b)=>b.f.r19-a.f.r19)[0];
const best=JSON.parse(fs.readFileSync('refine.json'))[0];
for(const [key,th,beam] of [['fit',best.th,'peak'],['maxr19',pin(mx.th,mx.f.Pdn),'peak']]){
  const e=A.envOf(th); const u=D.observe(M,e,G.map(p=>p*K),+1,1064,0,{beam}).y, d=D.observe(M,e,G.map(p=>p*K),-1,1064,0,{beam}).y;
  out[key]={P:G,u,d,th};
}
// gauss 버전: 같은 매개변수 집합에서 P_dn(가우스) 를 6.96 에 맞춤
{ const e0=A.envOf(mx.th); const Gg=D.logGrid(0.3,300,80); const od=D.observe(M,e0,Gg.map(p=>p*K),-1,1064,0,{beam:'gauss'}).y;
  let bd=0,jd=0; for(let i=0;i<Gg.length-1;i++){ const b=Math.log(od[i+1]/od[i]); if(b>bd){bd=b;jd=i;} }
  const th=pin(mx.th,Gg[jd+1]); const e=A.envOf(th);
  out.gauss={P:G,u:D.observe(M,e,G.map(p=>p*K),+1,1064,0,{beam:'gauss'}).y,d:D.observe(M,e,G.map(p=>p*K),-1,1064,0,{beam:'gauss'}).y,th}; }
fs.writeFileSync('curves.json',JSON.stringify(out)); console.log('ok',best.chi2);
