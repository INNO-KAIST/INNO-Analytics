const A=require('./fitA.js'); const fs=require('fs');
let all=[]; for(const f of fs.readdirSync('.').filter(f=>/^screen_\d+\.json$/.test(f))) all=all.concat(JSON.parse(fs.readFileSync(f)));
const cand=all.filter(o=>o.hyst>1.08&&o.hyst<1.45 && o.Pdn>1.2 && o.Pdn<50);
console.log('screened',all.length,'bistable',all.filter(o=>o.hyst>1.05).length,'cand',cand.length);
const res=[];
const lim=+process.argv[2]||40;
cand.sort((a,b)=>Math.abs(Math.log(a.hyst/1.2))-Math.abs(Math.log(b.hyst/1.2)));
for(const o of cand.slice(0,lim)){
  const th=o.th.slice(); const d=Math.log10(o.Pdn/6.96); th[0]+=d; th[1]+=d;
  const r0=A.resid(th); const r=A.lmfd(th,80);
  res.push({hyst0:o.hyst,chi0:r0?A.c2(r0.r):null,chi2:r.chi2,th:r.th});
  console.log(o.hyst.toFixed(2),(r0?A.c2(r0.r):NaN).toFixed(0),'->',r.chi2.toFixed(1),r.th.map(v=>v.toFixed(2)).join(' '));
}
res.sort((a,b)=>a.chi2-b.chi2); fs.writeFileSync('refine.json',JSON.stringify(res));
