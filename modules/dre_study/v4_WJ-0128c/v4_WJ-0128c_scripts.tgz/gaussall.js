const A=require('./fitA.js'); const {D,M,K}=A; const fs=require('fs');
let all=[]; for(const f of fs.readdirSync('.').filter(f=>/^screen_\d+\.json$/.test(f))) all=all.concat(JSON.parse(fs.readFileSync(f)));
const bi=all.filter(o=>o.hyst>1.05&&o.hyst<2&&o.Pdn>1.1&&o.Pup<55);
const out=[];
for(const s of bi){ const e=A.envOf(s.th); const G=D.logGrid(0.3,300,60).map(p=>p*K);
 try{ const ou=D.observe(M,e,G,+1,1064,0,{beam:"gauss"}), od=D.observe(M,e,G,-1,1064,0,{beam:"gauss"});
  let bu=0,ju=0,bd=0,jd=0; for(let i=0;i<G.length-1;i++){ const a=Math.log(ou.y[i+1]/ou.y[i]); if(a>bu){bu=a;ju=i;} const b=Math.log(od.y[i+1]/od.y[i]); if(b>bd){bd=b;jd=i;} }
  const Pdn=G[jd+1], y0=od.y[jd+1]; const at=r=>od.y[G.findIndex(g=>g>=Pdn*r)];
  out.push({u:{hyst:s.hyst,r19:s.r19,r12:s.r12,jd:s.jumpD},g:{hyst:G[ju+1]/G[jd+1],r19:at(1.87)/y0,r12:at(1.2)/y0,jd:Math.exp(bd)}}); }catch(e){}
}
fs.writeFileSync('feat_ug.json',JSON.stringify(out)); console.log(out.length);
