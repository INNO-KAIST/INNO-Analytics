// 표적 탐색: 히스테리시스 1.15–1.25 와 접힘 대비 ≥50 을 지키면서 위 가지 상승폭 y(1.87·P_dn)/y(P_dn⁺) 를 최대화
const A=require('./fitA.js'); const {D,M,K,names}=A;
const lo=[-30,-24,0,-4,0,-2,-3], hi=[-17,-13,10,-0.0005,11,8,8];
function feat(th){
  const e=A.envOf(th); const G=D.logGrid(0.3,300,80);
  let yu,yd; try{ yu=D.sweep(M,e,G.map(p=>p*K),+1,1064).n.map(x=>x[2]); yd=D.sweep(M,e,G.map(p=>p*K),-1,1064).n.map(x=>x[2]); }catch(err){ return null; }
  let bu=0,ju=0,bd=0,jd=0; for(let i=0;i<G.length-1;i++){ const a=Math.log(yu[i+1]/yu[i]); if(a>bu){bu=a;ju=i;} const b=Math.log(yd[i+1]/yd[i]); if(b>bd){bd=b;jd=i;} }
  const Pdn=G[jd+1], hyst=G[ju+1]/G[jd+1]; const y0=yd[jd+1];
  const at=r=>{ const p=Pdn*r; let i=G.findIndex(g=>g>=p); return yd[i]; };
  return {hyst,jd:Math.exp(bd),r12:at(1.2)/y0,r19:at(1.87)/y0,Pdn};
}
function obj(th){
  for(let j=0;j<th.length;j++) if(th[j]<lo[j]||th[j]>hi[j]) return 1e9;
  const f=feat(th); if(!f) return 1e9;
  let pen=0; if(f.hyst<1.15) pen+=50*Math.log(1.15/f.hyst)+ (f.hyst<1.03?5:0); if(f.hyst>1.25) pen+=50*Math.log(f.hyst/1.25);
  if(f.jd<50) pen+=Math.log(50/f.jd);
  return -Math.log(f.r19)+pen;
}
function nm(f,x0,step,iters){
  const n=x0.length; let S=[x0.slice()]; for(let i=0;i<n;i++){ const x=x0.slice(); x[i]+=step; S.push(x); }
  let F=S.map(f);
  for(let it=0;it<iters;it++){
    const o=[...S.keys()].sort((a,b)=>F[a]-F[b]); S=o.map(i=>S[i]); F=o.map(i=>F[i]);
    const c=new Array(n).fill(0); for(let i=0;i<n;i++) for(let j=0;j<n;j++) c[j]+=S[i][j]/n;
    const xr=c.map((v,j)=>v+(v-S[n][j])); const fr=f(xr);
    if(fr<F[0]){ const xe=c.map((v,j)=>v+2*(v-S[n][j])); const fe=f(xe); if(fe<fr){S[n]=xe;F[n]=fe;} else {S[n]=xr;F[n]=fr;} }
    else if(fr<F[n-1]){ S[n]=xr;F[n]=fr; }
    else { const xc=c.map((v,j)=>v+0.5*(S[n][j]-v)); const fc=f(xc); if(fc<F[n]){S[n]=xc;F[n]=fc;} else { for(let i=1;i<=n;i++){ S[i]=S[i].map((v,j)=>S[0][j]+0.5*(v-S[0][j])); F[i]=f(S[i]); } } }
  }
  const i=F.indexOf(Math.min(...F)); return {x:S[i],f:F[i]};
}
const fs=require('fs'); let all=[]; for(const f of fs.readdirSync('.').filter(f=>/^screen_\d+\.json$/.test(f))) all=all.concat(JSON.parse(fs.readFileSync(f)));
const seeds=all.filter(o=>o.hyst>1.08&&o.hyst<1.5&&o.Pdn>1.1&&o.Pup<55).sort((a,b)=>b.r19-a.r19).slice(0,+process.argv[2]||8);
const out=[];
for(const s of seeds){ let r=nm(obj,s.th,0.4,350); r=nm(obj,r.x,0.1,250); const f=feat(r.x); out.push({th:r.x,f}); console.log('start r19',s.r19.toFixed(2),'hyst',s.hyst.toFixed(2),' -> ',JSON.stringify(Object.fromEntries(Object.entries(f).map(([k,v])=>[k,+v.toFixed(3)]))),r.x.map(v=>v.toFixed(2)).join(' ')); }
fs.writeFileSync('maxr19.json',JSON.stringify(out));
