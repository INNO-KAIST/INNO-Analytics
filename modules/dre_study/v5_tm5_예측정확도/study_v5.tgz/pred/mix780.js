// NIR 750–850 nm 채널에서 ¹G₄→³H₅(780) 가중치를 바꿔 가며 위 가지 far 기울기 상한 (5준위, 히스테리시스 1.15–1.3)
process.env.LV='5'; const F=require('./feat5.js'); const {names,lo,hi,envOf,M,D}=F; const fs=require('fs');
const i4=M.idx['Tm:3H4'], i5=M.idx['Tm:1G4']; const mult=+process.argv[2]||1;
const ch={id:"NIRmix",terms:[[i4,0.856*636.01],[i5,0.45*2e4*mult]]};
const G=D.logGrid(10,1e9,70);
function feat(th){ const e=envOf(th); let su,sd; try{ su=D.sweep(M,e,G,1,1064).n; sd=D.sweep(M,e,G,-1,1064).n; }catch(err){ return null; }
  const yu=su.map(n=>D.channelValue(M,ch,n)), yd=sd.map(n=>D.channelValue(M,ch,n));
  let bu=0,ju=0,bd=0,jd=0; for(let i=0;i<G.length-1;i++){ const a=Math.log(yu[i+1]/yu[i]); if(a>bu){bu=a;ju=i;} const b=Math.log(yd[i+1]/yd[i]); if(b>bd){bd=b;jd=i;} }
  const Pdn=G[jd+1]; const at=r=>{ const i=G.findIndex(g=>g>=Pdn*r); return Math.log(yd[i]); };
  /* 780 몫 @ 1.8 P↓ */ const k=G.findIndex(g=>g>=Pdn*1.8); const n=sd[k]; const f780=(0.45*2e4*mult*n[i5])/(0.45*2e4*mult*n[i5]+0.856*636.01*n[i4]);
  return {hyst:G[ju+1]/Pdn,jd:Math.exp(bd),sFar:(at(1.9)-at(1.67))/Math.log(1.9/1.67),f780}; }
function obj(th){ for(let j=0;j<th.length;j++){ const n=names[j]; if(th[j]<lo[n]||th[j]>hi[n]) return 1e9; } const q=feat(th); if(!q) return 1e9;
  if(q.hyst<1.1||q.hyst>1.45||q.jd<20) return 1e6-q.hyst; let pen=0; if(q.hyst<1.15) pen+=30*Math.log(1.15/q.hyst); if(q.hyst>1.3) pen+=30*Math.log(q.hyst/1.3); if(q.jd<50) pen+=Math.log(50/q.jd); return -q.sFar+pen; }
function nm(f,x0,step,it){ const n=x0.length; let S=[x0.slice()]; for(let i=0;i<n;i++){ const x=x0.slice(); x[i]+=step; S.push(x); } let Fv=S.map(f);
  for(let k=0;k<it;k++){ const o=[...S.keys()].sort((a,b)=>Fv[a]-Fv[b]); S=o.map(i=>S[i]); Fv=o.map(i=>Fv[i]); const c=new Array(n).fill(0); for(let i=0;i<n;i++) for(let j=0;j<n;j++) c[j]+=S[i][j]/n;
    const xr=c.map((v,j)=>v+(v-S[n][j])), fr=f(xr);
    if(fr<Fv[0]){ const xe=c.map((v,j)=>v+2*(v-S[n][j])), fe=f(xe); if(fe<fr){S[n]=xe;Fv[n]=fe;} else {S[n]=xr;Fv[n]=fr;} } else if(fr<Fv[n-1]){S[n]=xr;Fv[n]=fr;}
    else { const xc=c.map((v,j)=>v+0.5*(S[n][j]-v)), fc=f(xc); if(fc<Fv[n]){S[n]=xc;Fv[n]=fc;} else for(let i=1;i<=n;i++){ S[i]=S[i].map((v,j)=>S[0][j]+0.5*(v-S[0][j])); Fv[i]=f(S[i]); } } }
  const i=Fv.indexOf(Math.min(...Fv)); return {x:S[i],f:Fv[i]}; }
let all=[]; for(const f of fs.readdirSync('.').filter(f=>/^s5_\d+\.json$/.test(f))) all=all.concat(JSON.parse(fs.readFileSync(f)));
const seeds=all.filter(r=>r.f.nir.hyst>1.05&&r.f.nir.hyst<1.6&&r.f.nir.jd>10).sort((a,b)=>b.f.nir.sFar-a.f.nir.sFar).slice(0,4);
let best=null; for(const s of seeds){ let r=nm(obj,s.th,0.4,200); r=nm(obj,r.x,0.1,120); const q=feat(r.x); if(!best||q.sFar>best.q.sFar) best={q,th:r.x}; console.log('×'+mult,'hyst',q.hyst.toFixed(3),'jd',q.jd.toFixed(0),'sFar',q.sFar.toFixed(3),'780몫@1.8P↓',q.f780.toFixed(2)); }
fs.writeFileSync(`mix780_${mult}.json`,JSON.stringify(best));
