/* 예측값 정확도: 참값 무작위(Lee 값 ±1 decade) + 미지의 강도 환산 오차 κ(10^(0.3·N(0,1))).
   데이터 조합 A: S-curve / B: +저파워 감쇠 1점 / C: B+상승시간 2점 / D: 농도 계열(4·8·15 %) S-curve+감쇠.
   공통: ³F₄ 비복사(W2nr)는 수명으로 안다고 둔다(고정). 측정 강도는 명목값(κ 모름). */
const D=require('/home/claude/dre/src/dre_core.js'); const fs=require('fs');
const combo=process.argv[2]||'A', NT=+process.argv[3]||10, seed=+process.argv[4]||7;
const T=D.templateLee(); const M=D.compile(T.spec); const EPH=D.photonEnergyJ(1064);
const FREE=['sG','sE','w3nr','k31','kQ22','kQ23'], ALL=['sG','sE','w2nr','w3nr','k31','kQ22','kQ23'];
const rnd=D.mulberry(seed); const g=()=>{ let u=0; while(!u) u=rnd(); return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*rnd()); };
const In=[...Array(45).keys()].map(i=>100*Math.pow(1000,i/44));   /* 명목 강도 W/cm² */
const cs=combo==='D'?[4,8,15]:[8];
function preds(env,c,kap,Inom){ /* env 는 참값 또는 피팅값, kap: 명목→실제 배율(피팅 쪽은 1) */
  const e=Object.assign({},env,{c}); const G=D.logGrid(Inom[0],Inom[Inom.length-1],60);
  const n3=D.sweep(M,e,G.map(v=>v*kap),1,1064).n.map(n=>n[2]); const sl=D.slopes(G,n3); let k=0; sl.forEach((v,i)=>{ if(v>sl[k]) k=i; });
  const Ith=G[k];                                       /* 명목 강도 기준 문턱 */
  const n2=D.sweep(M,e,[2*Ith*kap],1,1064).n[0][1];
  const t90=D.riseTime(M,e,1.5*Ith*kap,1064,0,0.9).t;
  const s31=e.k31*c*c, eta=s31/(s31+e.w3r+e.w3nr);
  const Iref=1e4; const kESA=e.sE*Iref*kap/EPH;           /* 명목 1e4 W/cm² 에서의 ESA 속도 [s⁻¹] — 환산 무관량 */
  return {kESA,eta,Ith,n2,t90,ratio:e.sE/e.sG,sE:e.sE,sG:e.sG,k31:e.k31,w3nr:e.w3nr,kQ23:e.kQ23};
}
const rows=[];
for(let s=0;s<NT;s++){
  const truth={}; Object.entries(T.params).forEach(([n,p])=>truth[n]=p.v); ALL.forEach(n=>truth[n]*=Math.pow(10,(rnd()*2-1)));
  const kap=Math.pow(10,0.3*g());
  const samples=cs.map(c=>{ const e=Object.assign({},truth,{c}); const w2nr=truth.w2nr*(c/8); const w3nr=truth.w3nr*(c/8); e.w2nr=w2nr; e.w3nr=w3nr;
    const n3=D.sweep(M,e,In.map(v=>v*kap),1,1064).n.map(n=>n[2]); const Sc=3e6/Math.max(...n3)*0.3, bg=40;
    const y=n3.map(v=>{ const y0=Sc*v; return Math.max(y0+bg+g()*Math.sqrt(y0+bg),1)*Math.exp(0.05*g())-bg; });
    const data=[{type:"scurve",ch:T.spec.channels[0].id,dir:1,I:In,y,sbg:Math.sqrt(bg),k:3,relErr:0.05}];
    if(combo!=='A'){ data.push({type:"decay",ch:T.spec.channels[0].id,I:[In[0]],t:[D.decayTime(M,e,In[0]*kap,1064,0).t*Math.exp(0.03*g())],relErr:0.03}); }
    if(combo==='C'){ const sl=D.slopes(In,n3); let k=0; sl.forEach((v,i)=>{ if(v>sl[k]) k=i; }); const Ir=[1.3*In[k],3*In[k]];
      data.push({type:"rise",ch:T.spec.channels[0].id,I:Ir,t:Ir.map(I=>D.riseTime(M,e,I*kap,1064,0,0.9).t*Math.exp(0.03*g())),frac:0.9,relErr:0.03}); }
    return {id:"c"+c,vars:{c},data,w2nr,w3nr}; });
  const params={}; Object.entries(T.params).forEach(([n,p])=>{ params[n]={v:p.v,fixed:!FREE.includes(n),lo:p.v/1000,hi:p.v*1000}; });
  params.w2nr={v:1,fixed:true,per:undefined}; params.w2nr.v=truth.w2nr;               /* 수명으로 앎 (c=8 기준) */
  if(combo==='D'){ params.w2nr={v:truth.w2nr,fixed:true}; params.w3nr.per="sample"; }
  /* 농도 계열: 비복사는 시료별(여기서는 c 비례로 만들었지만 피팅은 그 규칙을 모른다). w2nr 는 시료마다 달라서 식으로 고정 */
  const spec=JSON.parse(JSON.stringify(T.spec));
  if(combo==='D'){ spec.procs.forEach(p=>{ if(p.k==="w2r+w2nr") p.k="w2r+w2nr*c/8"; }); }
  const B=D.buildProblem({spec,nm:1064,beam:"peak",params,samples:samples.map(s=>({id:s.id,vars:s.vars,data:s.data}))});
  const t0=Date.now(); const ms=D.multistart(B,{starts:12,seed:s+1,maxit:150}); const best=ms[0];
  const eFit=si=>D.envFor(B,Float64Array.from(best.theta),si);
  const si8=cs.indexOf(8); const pT=preds(Object.assign({},truth),8,kap,In), pF=preds(eFit(si8),8,1,In);
  const err=Object.fromEntries(Object.keys(pT).map(k=>[k,Math.log10(pF[k]/pT[k])]));
  /* 허용 앙상블 퍼짐: Δχ² ≤ 3.84·s² 인 출발점 끝점들의 예측 범위 */
  const info=D.dofInfo(B,best); const thr=3.84*info.s2; const acc=ms.filter(r=>r.chi2-best.chi2<=thr);
  const ens=acc.map(r=>{ try{ return preds(D.envFor(B,Float64Array.from(r.theta),si8),8,1,In); }catch(e){ return null; } }).filter(Boolean);
  const spread=Object.fromEntries(Object.keys(pT).map(k=>{ const v=ens.map(p=>Math.log10(p[k])).filter(isFinite); return [k,v.length?Math.max(...v)-Math.min(...v):NaN]; }));
  rows.push({s,kap,err,spread,nacc:acc.length,chi2:best.chi2,time:(Date.now()-t0)/1000});
  console.log(combo,s,'κ',kap.toFixed(2),'t',((Date.now()-t0)/1000).toFixed(0)+'s','acc',acc.length,Object.entries(err).map(([k,v])=>k+':'+v.toFixed(2)).join(' '));
}
fs.writeFileSync(`pred_${combo}.json`,JSON.stringify(rows));
const med=a=>{ const b=a.filter(isFinite).sort((x,y)=>x-y); return b.length?b[Math.floor(b.length/2)]:NaN; };
const q90=a=>{ const b=a.filter(isFinite).sort((x,y)=>x-y); return b.length?b[Math.min(b.length-1,Math.floor(b.length*0.9))]:NaN; };
console.log('\n조합',combo,'— |log10(예측/참)| 중앙값 · 90% · 앙상블 퍼짐 중앙값');
Object.keys(rows[0].err).forEach(k=>console.log(k.padEnd(6),med(rows.map(r=>Math.abs(r.err[k]))).toFixed(3),q90(rows.map(r=>Math.abs(r.err[k]))).toFixed(3),med(rows.map(r=>r.spread[k])).toFixed(3)));
