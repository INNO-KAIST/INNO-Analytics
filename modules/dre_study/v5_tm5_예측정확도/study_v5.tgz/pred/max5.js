const F=require('./feat5.js'); const {feat,names,lo,hi,D}=F; const fs=require('fs');
const L=+process.env.LV||5, key=process.argv[2]||'nir', mode=process.argv[3]||'max';
const G=D.logGrid(10,1e9,70);
function obj(th){ for(let j=0;j<th.length;j++){ const n=names[j]; if(th[j]<lo[n]||th[j]>hi[n]) return 1e9; }
  const f=feat(th,G); if(!f) return 1e9; const q=f[key];
  if(q.hyst<1.1||q.hyst>1.45||q.jd<20) return 1e6-q.hyst;
  let pen=0; if(q.hyst<1.15) pen+=30*Math.log(1.15/q.hyst); if(q.hyst>1.3) pen+=30*Math.log(q.hyst/1.3); if(q.jd<50) pen+=Math.log(50/q.jd);
  if(mode==='max') return -q.sFar+pen;
  /* joint: NIR sFar → 1.2, 청색−NIR → 1.4 */
  return (q.sFar-1.2)**2/0.01+((f.blue.sFar-q.sFar)-1.4)**2/0.04+pen; }
function nm(f,x0,step,it){ const n=x0.length; let S=[x0.slice()]; for(let i=0;i<n;i++){ const x=x0.slice(); x[i]+=step; S.push(x); } let Fv=S.map(f);
  for(let k=0;k<it;k++){ const o=[...S.keys()].sort((a,b)=>Fv[a]-Fv[b]); S=o.map(i=>S[i]); Fv=o.map(i=>Fv[i]); const c=new Array(n).fill(0); for(let i=0;i<n;i++) for(let j=0;j<n;j++) c[j]+=S[i][j]/n;
    const xr=c.map((v,j)=>v+(v-S[n][j])), fr=f(xr);
    if(fr<Fv[0]){ const xe=c.map((v,j)=>v+2*(v-S[n][j])), fe=f(xe); if(fe<fr){S[n]=xe;Fv[n]=fe;} else {S[n]=xr;Fv[n]=fr;} } else if(fr<Fv[n-1]){S[n]=xr;Fv[n]=fr;}
    else { const xc=c.map((v,j)=>v+0.5*(S[n][j]-v)), fc=f(xc); if(fc<Fv[n]){S[n]=xc;Fv[n]=fc;} else for(let i=1;i<=n;i++){ S[i]=S[i].map((v,j)=>S[0][j]+0.5*(v-S[0][j])); Fv[i]=f(S[i]); } } }
  const i=Fv.indexOf(Math.min(...Fv)); return {x:S[i],f:Fv[i]}; }
let all=[]; for(const f of fs.readdirSync('.').filter(f=>new RegExp(`^s${L}_\\d+\\.json$`).test(f))) all=all.concat(JSON.parse(fs.readFileSync(f)));
const seeds=all.filter(r=>r.f[key].hyst>1.05&&r.f[key].hyst<1.6&&r.f[key].jd>10).sort((a,b)=>b.f[key].sFar-a.f[key].sFar).slice(0,+process.argv[4]||5);
console.log('L',L,key,mode,'seeds',seeds.length);
const out=[]; for(const s of seeds){ let r=nm(obj,s.th,0.4,220); r=nm(obj,r.x,0.1,150); const f=feat(r.x,G);
  out.push({th:r.x,f}); console.log(' ->',key,'hyst',f[key].hyst.toFixed(3),'jd',f[key].jd.toFixed(0),'sFar',f[key].sFar.toFixed(3),'sMid',f[key].sMid.toFixed(2),'| 800만 sFar',f.n800.sFar.toFixed(2),'| 청색−NIR',(f.blue.sFar-f.nir.sFar).toFixed(2)); }
fs.writeFileSync(`max${L}_${key}_${mode}.json`,JSON.stringify(out));
