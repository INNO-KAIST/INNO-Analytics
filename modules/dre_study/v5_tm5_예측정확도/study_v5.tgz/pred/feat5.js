// Tm 5/6준위 점 방출체: 위 가지 기울기·히스테리시스·청색–NIR 기울기 차 (WJ-0128c 반례 재시험)
const D=require('/home/claude/dre/src/dre_core.js');
const L=+process.env.LV||5; const T=D.templateTm(L); const M=D.compile(T.spec);
const base=Object.assign(Object.fromEntries(Object.entries(T.params).map(([k,p])=>[k,p.v])),{c:30});
const names=L===6?["sG","sE1","sE2","w2nr","w3nr","w6","cCR","cUC23","cUC22","cCR2"]:["sG","sE1","sE2","w2nr","w3nr","w6","cCR","cUC23","cUC22"];
const lo={sG:-28,sE1:-24,sE2:-25,w2nr:-1,w3nr:-1,w6:2,cCR:-21,cUC23:-24,cUC22:-24,cCR2:-22}, hi={sG:-21,sE1:-17,sE2:-18,w2nr:6,w3nr:7,w6:7,cCR:-13,cUC23:-15,cUC22:-15,cCR2:-14};
const ch=id=>M.channels.findIndex(c=>c.id.startsWith(id));
const C800=ch("800"), CNIR=ch("NIR"), CB=L===6?ch("청색"):ch("475");
const envOf=th=>{ const e=Object.assign({},base); names.forEach((n,j)=>e[n]=Math.pow(10,th[j])); return e; };
const val=(n,k)=>D.channelValue(M,M.channels[k],n);
function feat(th,G){
  G=G||D.logGrid(10,1e9,40); const e=envOf(th); let su,sd;
  try{ su=D.sweep(M,e,G,1,1064).n; sd=D.sweep(M,e,G,-1,1064).n; }catch(err){ return null; }
  const out={};
  for(const [key,k] of [["n800",C800],["nir",CNIR],["blue",CB]]){
    const yu=su.map(n=>val(n,k)), yd=sd.map(n=>val(n,k));
    let bu=0,ju=0,bd=0,jd=0; for(let i=0;i<G.length-1;i++){ const a=Math.log(yu[i+1]/yu[i]); if(a>bu){bu=a;ju=i;} const b=Math.log(yd[i+1]/yd[i]); if(b>bd){bd=b;jd=i;} }
    const Pdn=G[jd+1]; const at=r=>{ const i=G.findIndex(g=>g>=Pdn*r); return i<0?NaN:Math.log(yd[i]); };
    out[key]={hyst:G[ju+1]/Pdn,jd:Math.exp(bd),sFar:(at(1.9)-at(1.67))/Math.log(1.9/1.67),sMid:(at(1.6)-at(1.28))/Math.log(1.6/1.28),Pdn};
  }
  return out;
}
module.exports={feat,names,lo,hi,envOf,M,D,T};
if(require.main===module){
  const N=+process.argv[2]||2000, rnd=D.mulberry(+process.argv[3]||1); const res=[];
  for(let k=0;k<N;k++){ const th=names.map(n=>lo[n]+rnd()*(hi[n]-lo[n])); const f=feat(th); if(f) res.push({th,f}); }
  require('fs').writeFileSync(`s${L}_${process.argv[3]||1}.json`,JSON.stringify(res));
  const bi=res.filter(r=>r.f.nir.hyst>1.1&&r.f.nir.hyst<1.4&&r.f.nir.jd>30);
  console.log(`L${L} N ${res.length} bistable(1.1–1.4, 대비≥30) ${bi.length}`);
  const q=a=>a.sort((x,y)=>x-y), mx=a=>a.length?Math.max(...a).toFixed(2):'-';
  console.log(' 800만 sFar max',mx(bi.map(r=>r.f.n800.sFar)),' NIR필터 sFar max',mx(bi.map(r=>r.f.nir.sFar)),' sMid max',mx(bi.map(r=>r.f.nir.sMid)));
  console.log(' 청색−NIR sFar 차 범위',bi.length?[Math.min(...bi.map(r=>r.f.blue.sFar-r.f.nir.sFar)).toFixed(2),Math.max(...bi.map(r=>r.f.blue.sFar-r.f.nir.sFar)).toFixed(2)].join('..'):'-');
}
